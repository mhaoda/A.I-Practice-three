/*
 * guess user's goal destination based on the preference
 */
package Part_two;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import org.encog.ml.data.MLData;
import org.encog.ml.data.basic.BasicMLData;
import org.encog.neural.networks.BasicNetwork;
import org.encog.persist.EncogDirectoryPersistence;

public class Guess {
	String destination;
	ArrayList<String> cityArray = new ArrayList<String>();

	public String getDestination() {
		return destination;
	}
	
	/*
	 * constructor
	 */
	public Guess() {
		super();
		// TODO Auto-generated constructor stub
		// getting all destination in the network
		try {
			BufferedReader bf = new BufferedReader(new FileReader("output_two.txt"));
			String str = bf.readLine();
			String[] city = str.split(",");
			for (int i = 0; i < city.length; i++) {
				cityArray.add(city[i]);
			}
			bf.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	/*
	 * select the destination corresponding the computed result.
	 * @param the larger column number among the computed data
	 */
	public void selectCity(int maxSign) {
		System.out.println();
		System.out.println(cityArray.get(maxSign));
		destination = cityArray.get(maxSign);
	}

	/*
	 * computing with the network, and getting the larger column number among the data array.
	 * @param the input dataset
	 */
	public int guess(double[] city) {
		// TODO Auto-generated constructor stub
		System.out.println("Loading network");
		BasicNetwork loaded_net = (BasicNetwork) EncogDirectoryPersistence.loadObject(new File("network_two.eg"));
		MLData data = new BasicMLData(city);
		MLData output = loaded_net.compute(data);
		System.out.print("input = ");
		for (int i = 0; i < data.size(); i++) {
			System.out.print(data.getData(i) + ", ");
		}

		System.out.println();
		System.out.print("actual = ");
		for (int i = 0; i < output.size(); i++) {
			System.out.print(output.getData(i) + ", ");
		}

		double max = output.getData(0);
		int maxSign = 0;
		for (int i = 0; i < output.size(); i++) {
			if (output.getData(i) > max) {
				max = output.getData(i);
				maxSign = i;
			}
		}
		return maxSign;
	}
}
