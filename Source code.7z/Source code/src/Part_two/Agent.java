/*
 * this is the agent for part two.
 */
package Part_two;
import java.io.IOException;


public class Agent {
	String destination;
	Training_Table getCsv = new Training_Table();
	Learning tt = new Learning();
	Guess cs = new Guess();
	
	public Training_Table getGetCsv() {
		return getCsv;
	}

	public Learning getTt() {
		return tt;
	}

	public Guess getCs() {
		return cs;
	}

	public String getDestination() {
		return destination;
	}
	
	public Agent() {
		super();
		// TODO Auto-generated constructor stub
		try {
			InitialAgent();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	//getting input and output from the external files
	public void InitialAgent() throws IOException {
		getCsv.getCsvData("trip.csv", 9);
		double INPUT[][] = getCsv.getInput();
		double OUTPUT[][] = getCsv.getOutput();
		tt.learn(INPUT, OUTPUT);
	}
	
	/*
	 * get the guessed destination
	 * @param the preference array obtained from the user
	 */
	public void guess(double[] preference) throws IOException {
		int maxSign = cs.guess(preference);
		cs.selectCity(maxSign);
		destination = cs.getDestination();
	}
}
