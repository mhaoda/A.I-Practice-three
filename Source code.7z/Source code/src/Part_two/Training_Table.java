package Part_two;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.StringTokenizer;

public class Training_Table {
	public double[][] input;
	public double[][] output;
	
	public double[][] getInput() {
		return input;
	}

	public double[][] getOutput() {
		return output;
	}
	
	public void setInput(double[][] input) {
		this.input = input;
	}

	public void setOutput(double[][] output) {
		this.output = output;
	}

	// getting the data set from the external file.
	public void getCsvData(String filePath, int COLUMN_NUM) throws IOException {
		BufferedReader br = new BufferedReader(new FileReader(new File(filePath)));
		String line = "";
		ArrayList<String[]> lineList = new ArrayList<String[]>();
		while ((line = br.readLine()) != null) {
			StringTokenizer st = new StringTokenizer(line, ","); 
			String[] currCol = new String[COLUMN_NUM];
			for (int i = 0; i < COLUMN_NUM; i++) {
				if (st.hasMoreTokens()) {
					currCol[i] = st.nextToken();
				}
			}
			lineList.add(currCol);
		}
		String[][] str = new String[lineList.size()][COLUMN_NUM];
		for (int i = 0; i < lineList.size(); i++) {
			for (int j = 0; j < COLUMN_NUM; j++) {
				str[i][j] = lineList.get(i)[j];
			}
		}
		br.close();

		//the rule for transforming
		input = new double[str.length - 1][str[0].length - 1];
		output = new double[str.length - 1][5];
		double[] Spain = { 1, 0, 0, 0, 0};
		double[] Greece = { 0, 1, 0, 0, 0};
		double[] Egypt = { 0, 0, 1, 0, 0};
		double[] Australia = { 0, 0, 0, 1, 0};
		double[] Argentina = { 0, 0, 0, 0, 1};

		for (int i = 1; i < str.length; i++) {
			for (int j = 0; j < str[i].length; j++) {
				if (str[i][j].equals("Yes")) {
					input[i - 1][j] = 1.0;
				} else if (str[i][j].equals("No")) {
					input[i - 1][j] = 0;
				} else if (str[i][j].equals("Spain")) {
					output[i - 1] = Spain;
				} else if (str[i][j].equals("Greece")) {
					output[i - 1] = Greece;
				} else if (str[i][j].equals("Egypt")) {
					output[i - 1] = Egypt;
				} else if (str[i][j].equals("Australia")) {
					output[i - 1] = Australia;
				} else if (str[i][j].equals("Argentina")) {
					output[i - 1] = Argentina;
				} 
			}
		}
	}
	//update the input array, adding the new input obtained from the user.
	public double[][] addNewCity_Input(double[] newInput, double[][] input){
		double[][] transferInput = new double[input.length+1][input[0].length];
		for(int i=0;i<transferInput.length-1;i++) {
			for(int j=0;j<transferInput[0].length;j++) {
				transferInput[i][j] = input[i][j];
			}
		}
		for(int i=0;i<transferInput[transferInput.length-1].length;i++) {
			transferInput[transferInput.length-1][i] = newInput[i];
		}
		
		input = transferInput;
		setInput(input);
		return input;
	}
	//update the output array, adding the new output obtained from the user.
	public double[][] addNewCity_Output(double[][] output){
		double[][] transferOutput = new double[output.length+1][output[0].length + 1];
		for(int i=0;i<transferOutput.length;i++) {
			for(int j=0;j<transferOutput[0].length;j++) {
				if(i==output.length) {
					for(int y = 0;y<transferOutput[0].length;y++) {
						if(y == transferOutput[0].length-1) {
							transferOutput[i][y] = 1;
						}else {
						transferOutput[i][y] = 0;
						}
					}
				}else {
					try {
						transferOutput[i][j] = output[i][j];
					} catch (Exception e) {
						// TODO Auto-generated catch block
						transferOutput[i][j] = 0;
					}
				}
			}
		}
		output = transferOutput;
		return output;
	}
//	public void addNewCity(double[][] newInput, double[][] newOutput, double[][] input, double[][] output) {
//		double[][] transferInput = new double[input.length+1][input[0].length];
//		double[][] transferOutput = new double[output.length+1][output[0].length + 1];
//		
//		for(int i=0;i<transferInput.length-1;i++) {
//			for(int j=0;j<transferInput[0].length;j++) {
//				transferInput[i][j] = input[i][j];
//			}
//		}
//		
//		for(int i=0;i<transferInput[transferInput.length-1].length;i++) {
//			transferInput[transferInput.length-1][i] = newInput[0][i];
//		}
//		setInput(transferInput);
//		
//		for(int i=0;i<transferOutput.length;i++) {
//			for(int j=0;j<transferOutput[0].length;j++) {
//				if(i==output.length) {
//					transferOutput[i][j] = newOutput[0][j];
//				}else {
//					try {
//						transferOutput[i][j] = output[i][j];
//					} catch (Exception e) {
//						// TODO Auto-generated catch block
//						transferInput[i][j] = 0;
//					}
//				}
//			}
//		}
//		setOutput(transferOutput);		
//		System.out.println("GetCsv_test  " + getInput().length + " " +getOutput().length );
//	}
}
