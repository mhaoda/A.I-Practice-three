/*
 * the main window that the program interact with the user.
 */
package Part_two;
import java.awt.EventQueue;
import java.awt.Font;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JCheckBox;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JButton;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import javax.swing.JPopupMenu;

public class MainWindow extends JFrame {
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JLabel t1;
	private JLabel t2;
	private JCheckBox Yes_1;
	private JCheckBox No_1;
	private JLabel t3;
	private JCheckBox Yes_2;
	private JCheckBox No_2;
	private JLabel t4;
	private JCheckBox Yes_3;
	private JCheckBox No_3;
	private JLabel t5;
	private JCheckBox Yes_4;
	private JCheckBox No_4;
	private JLabel t6;
	private JCheckBox Yes_5;
	private JCheckBox No_5;
	private JLabel t7;
	private JCheckBox Yes_6;
	private JCheckBox No_6;
	private JLabel t8;
	private JCheckBox Yes_7;
	private JCheckBox No_7;
	private JCheckBox Yes_8;
	private JCheckBox No_8;
	private ArrayList<JCheckBox> checkList = new ArrayList<JCheckBox>();
	Agent agent = new Agent();
	double[] preference = new double[8];
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MainWindow frame = new MainWindow();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 * @throws IOException 
	 */
	public MainWindow() throws IOException {
		setTitle(" AI Travel Genie");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 736);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		t1 = new JLabel();
		t1.setFont(new Font("Tahoma", Font.PLAIN, 18));
		t1.setBounds(5, 5, 418, 26);
		t1.setText("Do you want a short stay?");
		contentPane.add(t1);
		
		Yes_8 = new JCheckBox("YES");
		Yes_8.setFont(new Font("Tahoma", Font.PLAIN, 18));
		Yes_8.setBounds(43, 43, 139, 29);
		contentPane.add(Yes_8);
		checkList.add(Yes_8);
		
		No_8 = new JCheckBox("NO");
		No_8.setFont(new Font("Tahoma", Font.PLAIN, 18));
		No_8.setBounds(217, 43, 139, 29);
		contentPane.add(No_8);
		checkList.add(No_8);
		
		t2 = new JLabel();
		t2.setFont(new Font("Tahoma", Font.PLAIN, 18));
		t2.setText("Do you want to see the penguins?");
		t2.setBounds(5, 84, 351, 26);
		contentPane.add(t2);
		t2.setVisible(false);
		
		Yes_1 = new JCheckBox("YES");
		Yes_1.setFont(new Font("Tahoma", Font.PLAIN, 18));
		Yes_1.setBounds(43, 122, 139, 29);
		contentPane.add(Yes_1);
		checkList.add(Yes_1);
		Yes_1.setVisible(false);
		
		No_1 = new JCheckBox("NO");
		No_1.setFont(new Font("Tahoma", Font.PLAIN, 18));
		No_1.setBounds(217, 122, 139, 29);
		contentPane.add(No_1);
		checkList.add(No_1);
		No_1.setVisible(false);
		
		t3 = new JLabel();
		t3.setFont(new Font("Tahoma", Font.PLAIN, 18));
		t3.setText("Do you want to visit the longest river?");
		t3.setBounds(5, 163, 351, 26);
		contentPane.add(t3);
		t3.setVisible(false);
		
		Yes_2 = new JCheckBox("YES");
		Yes_2.setFont(new Font("Tahoma", Font.PLAIN, 18));
		Yes_2.setBounds(43, 203, 139, 29);
		contentPane.add(Yes_2);
		checkList.add(Yes_2);
		Yes_2.setVisible(false);
		
		No_2 = new JCheckBox("NO");
		No_2.setFont(new Font("Tahoma", Font.PLAIN, 18));
		No_2.setBounds(217, 203, 139, 29);
		contentPane.add(No_2);
		checkList.add(No_2);
		No_2.setVisible(false);
		
		t4 = new JLabel();
		t4.setFont(new Font("Tahoma", Font.PLAIN, 18));
		t4.setText("Do you like island?");
		t4.setBounds(5, 244, 197, 26);
		contentPane.add(t4);
		t4.setVisible(false);
		
		Yes_3 = new JCheckBox("YES");
		Yes_3.setFont(new Font("Tahoma", Font.PLAIN, 18));
		Yes_3.setBounds(43, 282, 139, 29);
		contentPane.add(Yes_3);
		checkList.add(Yes_3);
		Yes_3.setVisible(false);
		
		No_3 = new JCheckBox("NO");
		No_3.setFont(new Font("Tahoma", Font.PLAIN, 18));
		No_3.setBounds(217, 282, 139, 29);
		contentPane.add(No_3);
		checkList.add(No_3);
		No_3.setVisible(false);
		
		t5 = new JLabel();
		t5.setFont(new Font("Tahoma", Font.PLAIN, 18));
		t5.setText("Do you want to walk along the seaside?");
		t5.setBounds(5, 323, 336, 26);
		contentPane.add(t5);
		t5.setVisible(false);
		
		Yes_4 = new JCheckBox("YES");
		Yes_4.setFont(new Font("Tahoma", Font.PLAIN, 18));
		Yes_4.setBounds(43, 361, 139, 29);
		contentPane.add(Yes_4);
		checkList.add(Yes_4);
		Yes_4.setVisible(false);
		
		No_4 = new JCheckBox("NO");
		No_4.setFont(new Font("Tahoma", Font.PLAIN, 18));
		No_4.setBounds(217, 361, 139, 29);
		contentPane.add(No_4);
		checkList.add(No_4);
		No_4.setVisible(false);
		
		t6 = new JLabel();
		t6.setFont(new Font("Tahoma", Font.PLAIN, 18));
		t6.setText("Are you interested in the historical place?");
		t6.setBounds(5, 402, 336, 26);
		contentPane.add(t6);
		t6.setVisible(false);
		
		Yes_5 = new JCheckBox("YES");
		Yes_5.setFont(new Font("Tahoma", Font.PLAIN, 18));
		Yes_5.setBounds(43, 440, 139, 29);
		contentPane.add(Yes_5);
		checkList.add(Yes_5);
		Yes_5.setVisible(false);
		
		No_5 = new JCheckBox("NO");
		No_5.setFont(new Font("Tahoma", Font.PLAIN, 18));
		No_5.setBounds(217, 440, 139, 29);
		contentPane.add(No_5);
		checkList.add(No_5);
		No_5.setVisible(false);
		
		t7 = new JLabel();
		t7.setFont(new Font("Tahoma", Font.PLAIN, 18));
		t7.setText("Can you speak Spanish?");
		t7.setBounds(5, 481, 336, 26);
		contentPane.add(t7);
		t7.setVisible(false);
		
		Yes_6 = new JCheckBox("YES");
		Yes_6.setFont(new Font("Tahoma", Font.PLAIN, 18));
		Yes_6.setBounds(43, 519, 139, 29);
		contentPane.add(Yes_6);
		checkList.add(Yes_6);
		Yes_6.setVisible(false);
		
		No_6 = new JCheckBox("NO");
		No_6.setFont(new Font("Tahoma", Font.PLAIN, 18));
		No_6.setBounds(217, 519, 139, 29);
		contentPane.add(No_6);
		checkList.add(No_6);
		No_6.setVisible(false);
		
		t8 = new JLabel();
		t8.setFont(new Font("Tahoma", Font.PLAIN, 18));
		t8.setText("Do you want to try some special food?");
		t8.setBounds(5, 560, 336, 26);
		contentPane.add(t8);
		t8.setVisible(false);
		
		Yes_7 = new JCheckBox("YES");
		Yes_7.setFont(new Font("Tahoma", Font.PLAIN, 18));
		Yes_7.setBounds(43, 598, 139, 29);
		contentPane.add(Yes_7);
		checkList.add(Yes_7);
		Yes_7.setVisible(false);
		
		No_7 = new JCheckBox("NO");
		No_7.setFont(new Font("Tahoma", Font.PLAIN, 18));
		No_7.setBounds(217, 598, 139, 29);
		contentPane.add(No_7);
		checkList.add(No_7);
		No_7.setVisible(false);
		
		Yes_8.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(Yes_8.isSelected()) {
					if(No_8.isSelected()) {
						No_8.setSelected(false);
					}
					preference[0] = 1;
				}
				
				if(!t2.isVisible()) {
					t2.setVisible(true);
					Yes_1.setVisible(true);
					No_1.setVisible(true);
				}
			}
		});
		No_8.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(No_8.isSelected()) {
					if(Yes_8.isSelected()) {
						Yes_8.setSelected(false);
					}
					preference[0] = 0;
				}
				
				if(!t2.isVisible()) {
					t2.setVisible(true);
					Yes_1.setVisible(true);
					No_1.setVisible(true);
				}
			}
		});
		
		
		
		Yes_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(Yes_1.isSelected()) {
					if(No_1.isSelected()) {
						No_1.setSelected(false);
					}
					preference[1] = 1;
				}
				
				if(!t3.isVisible()) {
					t3.setVisible(true);
					Yes_2.setVisible(true);
					No_2.setVisible(true);
				}
			}
		});
		No_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(No_1.isSelected()) {
					if(Yes_1.isSelected()) {
						Yes_1.setSelected(false);
					}
					preference[1] = 0;
				}
				
				if(!t3.isVisible()) {
					t3.setVisible(true);
					Yes_2.setVisible(true);
					No_2.setVisible(true);
				}
			}
		});
		
		
		
		Yes_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(Yes_2.isSelected()) {
					if(No_2.isSelected()) {
						No_2.setSelected(false);
					}
					preference[2] = 1;
				}
				
				if(!t4.isVisible()) {
					t4.setVisible(true);
					Yes_3.setVisible(true);
					No_3.setVisible(true);
				}
			}
		});
		No_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(No_2.isSelected()) {
					if(Yes_2.isSelected()) {
						Yes_2.setSelected(false);
					}
					preference[2] = 0;
				}
				
				if(!t4.isVisible()) {
					t4.setVisible(true);
					Yes_3.setVisible(true);
					No_3.setVisible(true);
				}
			}
		});
		
		Yes_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(Yes_3.isSelected()) {
					if(No_3.isSelected()) {
						No_3.setSelected(false);
					}
					preference[3] = 1;
				}
				
				if(!t5.isVisible()) {
					t5.setVisible(true);
					Yes_4.setVisible(true);
					No_4.setVisible(true);
				}
			}
		});
		No_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(No_3.isSelected()) {
					if(Yes_3.isSelected()) {
						Yes_3.setSelected(false);
					}
					preference[3] = 0;
				}
				
				if(!t5.isVisible()) {
					t5.setVisible(true);
					Yes_4.setVisible(true);
					No_4.setVisible(true);
				}
			}
		});
		
		
		Yes_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(Yes_4.isSelected()) {
					if(No_4.isSelected()) {
						No_4.setSelected(false);
					}
					preference[4] = 1;
				}
				//the early guess
				try {
					agent.guess(preference);
					int option= JOptionPane.showConfirmDialog(
							MainWindow.this, "Is your dream distination is " + agent.getDestination() , "Guess ",JOptionPane.YES_NO_OPTION); 
					if(option == JOptionPane.YES_OPTION) {
							dispose();
					}else {
						if(!t6.isVisible()) {
							t6.setVisible(true);
							Yes_5.setVisible(true);
							No_5.setVisible(true);
						}
					}
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		});
		No_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(No_4.isSelected()) {
					if(Yes_4.isSelected()) {
						Yes_4.setSelected(false);
					}
					preference[4] = 0;
				}
				try {
					agent.guess(preference);
					int option= JOptionPane.showConfirmDialog(
							MainWindow.this, "Is your dream distination is " + agent.getDestination() , "Guess ",JOptionPane.YES_NO_OPTION); 
					if(option == JOptionPane.YES_OPTION) {
						System.exit(0);
					}else {
						if(!t6.isVisible()) {
							t6.setVisible(true);
							Yes_5.setVisible(true);
							No_5.setVisible(true);
						}
					}
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		});
		
		Yes_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(Yes_5.isSelected()) {
					if(No_5.isSelected()) {
						No_5.setSelected(false);
					}
					preference[5] = 1;
				}
				
				if(!t7.isVisible()) {
					t7.setVisible(true);
					Yes_6.setVisible(true);
					No_6.setVisible(true);
				}
			}
		});
		No_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(No_5.isSelected()) {
					if(Yes_5.isSelected()) {
						Yes_5.setSelected(false);
					}
					preference[5] = 0;
				}
				
				if(!t7.isVisible()) {
					t7.setVisible(true);
					Yes_6.setVisible(true);
					No_6.setVisible(true);
				}
			}
		});
		
		Yes_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(Yes_6.isSelected()) {
					if(No_6.isSelected()) {
						No_6.setSelected(false);
					}
					preference[6] = 1;
				}
				
				if(!t8.isVisible()) {
					t8.setVisible(true);
					Yes_7.setVisible(true);
					No_7.setVisible(true);
				}
			}
		});
		No_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(No_6.isSelected()) {
					if(Yes_6.isSelected()) {
						Yes_6.setSelected(false);
					}
					preference[6] = 0;
				}
				
				if(!t8.isVisible()) {
					t8.setVisible(true);
					Yes_7.setVisible(true);
					No_7.setVisible(true);
				}
			}
		});
		
		Yes_7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(Yes_7.isSelected()) {
					if(No_7.isSelected()) {
						No_7.setSelected(false);
					}
					preference[7] = 1;
				}
			}
		});
		No_7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(No_7.isSelected()) {
					if(Yes_7.isSelected()) {
						Yes_7.setSelected(false);
					}
					preference[7] = 0;
				}
			}
		});
		
		JButton button = new JButton("Submit");
		button.setFont(new Font("Tahoma", Font.PLAIN, 18));
		button.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				//test the answer of the user.
				int checkNum = 0;
				for(int i=0;i<checkList.size();i++) {
					if(checkList.get(i).isSelected()) {
						checkNum++;
					}
				}
				
				double test = 0;
				for(int i=0;i<preference.length;i++) {
					if(preference[i]==0) {
						test++;
					}
				}
				if(checkNum != 8) {
					JLabel label = new JLabel("Please check every preference item");
	                label.setFont(new Font("Arial", Font.BOLD, 20));
	                JOptionPane.showMessageDialog(null, label, "About", JOptionPane.INFORMATION_MESSAGE);
				}else if(test == 8) {
					JLabel label = new JLabel("Please check at least one preference");
	                label.setFont(new Font("Arial", Font.BOLD, 20));
	                JOptionPane.showMessageDialog(null, label, "About", JOptionPane.INFORMATION_MESSAGE);
				}else {
					try {
						agent.guess(preference);
						int option= JOptionPane.showConfirmDialog(
								MainWindow.this, "Is your dream distination is " + agent.getDestination() , "Guess ",JOptionPane.YES_NO_OPTION); 
						if(option == JOptionPane.YES_OPTION) {
							//System.exit(0);
							dispose();
						}
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			}
		});
		button.setBounds(142, 639, 115, 29);
		contentPane.add(button);
	}
}
