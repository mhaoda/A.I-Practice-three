/*
 * this is the window for adding the new destination.
 */
import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class addWindow extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField textField;
	public static Agent agent;
	public static double[] preference;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					addWindow frame = new addWindow(agent, preference);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public addWindow(Agent agent, double[] preference) {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel l1 = new JLabel("Please input your destination :");
		l1.setFont(new Font("Tahoma", Font.PLAIN, 18));
		l1.setBounds(31, 13, 331, 43);
		contentPane.add(l1);
		
		textField = new JTextField();
		textField.setBounds(111, 84, 196, 43);
		contentPane.add(textField);
		textField.setColumns(10);
		
		//confirm button
		JButton btnConfirm = new JButton("Confirm");
		btnConfirm.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String destination = textField.getText();
				boolean success = agent.addNewCity(preference, destination);
				if(success) {
					//show the success information
					int option= JOptionPane.showConfirmDialog(
							addWindow.this, "Add success" , "Alert ",JOptionPane.YES_NO_OPTION); 
					if(option == JOptionPane.YES_OPTION) {
						dispose();
					}
				}else {
					//show the fail information
					JLabel label = new JLabel("Add Fail, because the existence of the destination.");
	                label.setFont(new Font("Arial", Font.BOLD, 20));
	                JOptionPane.showMessageDialog(null, label, "Alert", JOptionPane.INFORMATION_MESSAGE);
				}
			}
		});
		btnConfirm.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnConfirm.setBounds(59, 173, 115, 29);
		contentPane.add(btnConfirm);
		
		//the cancel button, closing window
		JButton btnCancel = new JButton("Cancel");
		btnCancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		btnCancel.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnCancel.setBounds(247, 173, 115, 29);
		contentPane.add(btnCancel);
	}
}
