/*
 * guess user's goal destination based on the preference
 */
package Part_one;

import java.io.File;
import java.util.ArrayList;

import org.encog.ml.data.MLData;
import org.encog.ml.data.basic.BasicMLData;
import org.encog.neural.networks.BasicNetwork;
import org.encog.persist.EncogDirectoryPersistence;

public class Guess {
	/*
	 * computing with the network, and getting the larger column number among the data array.
	 * @param the input data set
	 */
	public int guess(double[] city) {
		// TODO Auto-generated constructor stub
		System.out.println("Loading network");
		BasicNetwork loaded_net = (BasicNetwork) EncogDirectoryPersistence.loadObject(new File("network_one.eg"));
		MLData data = new BasicMLData(city);
		MLData output = loaded_net.compute(data);
		System.out.print("input = ");
		for(int i=0;i<data.size();i++) {
			System.out.print( data.getData(i) + ", ");
		}
		
		System.out.println();
		System.out.print("actual = ");
		for(int i=0;i<output.size();i++) {
			System.out.print( output.getData(i) + ", ");
		}
		
		double max = output.getData(0);
		int maxSign = 0;
		for (int i = 0; i < output.size(); i++) {
			if (output.getData(i) > max) {
				max = output.getData(i);
				maxSign = i;
			}
		}
		return maxSign;
	}
	
	/*
	 * select the destination corresponding the computed result.
	 * @param the larger column number among the computed data
	 */
	public String selectDestination(int maxSign) {
		ArrayList<String> cityArray = new ArrayList<String>();
		cityArray.add("Spain");
		cityArray.add("Greece");
		cityArray.add("Egypt");
		cityArray.add("Australia");
		cityArray.add("Argentina");
		//cityArray.add("China");
		String destination = cityArray.get(maxSign);
		return destination;
	}
}
