package Part_one;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.StringTokenizer;

public class Training_Table {
	public double[][] input;
	public double[][] output;
	
	public double[][] getInput() {
		return input;
	}

	public void setInput(double[][] input) {
		this.input = input;
	}

	public double[][] getOutput() {
		return output;
	}

	public void setOutput(double[][] output) {
		this.output = output;
	}

	// getting the data set from the external file.
	public void getCsvData(String filePath) throws IOException {
		BufferedReader br = new BufferedReader(new FileReader(new File(filePath)));
		String line = "";
		ArrayList<String[]> lineList = new ArrayList<String[]>();
		int COLUMN_NUM = 0;
		while ((line = br.readLine()) != null) {
			StringTokenizer st = new StringTokenizer(line, ","); 
			COLUMN_NUM = line.split(",").length;
			String[] currCol = new String[COLUMN_NUM]; 
			for (int i = 0; i < COLUMN_NUM; i++) {
				if (st.hasMoreTokens()) {
					currCol[i] = st.nextToken();
				}
			}
			lineList.add(currCol);
		}
		String[][] str = new String[lineList.size()][COLUMN_NUM];
		for (int i = 0; i < lineList.size(); i++) {
			for (int j = 0; j < COLUMN_NUM; j++) {
				str[i][j] = lineList.get(i)[j];
			}
		}
		br.close();

		input = new double[str.length - 1][str[0].length - 1];
		output = new double[str.length - 1][5];
		
		//output = new double[str.length - 1][6];

		//the rule for transforming
		double[] Spain = { 1, 0, 0, 0, 0 };
		double[] Greece = { 0, 1, 0, 0, 0 };
		double[] Egypt = { 0, 0, 1, 0, 0 };
		double[] Australia = { 0, 0, 0, 1, 0 };
		double[] Argentina = { 0, 0, 0, 0, 1 };
		
//		double[] Spain = { 1, 0, 0, 0, 0, 0 };
//		double[] Greece = { 0, 1, 0, 0, 0, 0 };
//		double[] Egypt = { 0, 0, 1, 0, 0, 0 };
//		double[] Australia = { 0, 0, 0, 1, 0, 0 };
//		double[] Argentina = { 0, 0, 0, 0, 1, 0 };
//		double[] China = { 0, 0, 0, 0, 0, 1};
		
		for (int i = 1; i < str.length; i++) {
			for (int j = 0; j < str[i].length; j++) {
				if (str[i][j].equals("Yes")) {
					input[i - 1][j] = 1.0;
				} else if (str[i][j].equals("No")) {
					input[i - 1][j] = 0;
				} else if (str[i][j].equals("Spain")) {
					output[i - 1] = Spain;
				} else if (str[i][j].equals("Greece")) {
					output[i - 1] = Greece;
				} else if (str[i][j].equals("Egypt")) {
					output[i - 1] = Egypt;
				} else if (str[i][j].equals("Australia")) {
					output[i - 1] = Australia;
				} else if (str[i][j].equals("Argentina")) {
					output[i - 1] = Argentina;
				} 
//					else if (str[i][j].equals("China")) {
//					output[i - 1] = China;
//				}
			}
		}
	}
	/*
	 * Test
	 */
//	public static void main(String[] args) throws IOException {
//		Training_Table tt = new Training_Table();
//		tt.getCsvData("trip.csv", 9);
//		double[][] INPUT = tt.getInput();
//		for(int i=0;i<INPUT.length;i++) {
//			System.out.println(i + " ");
//			for(int j=0;j<INPUT[i].length;j++) {
//				System.out.print(INPUT[i][j]);
//			}
//			System.out.println();
//		}
//	}
}
