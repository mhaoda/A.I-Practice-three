/*
 * this is the agent for par one
 */
package Part_one;

import java.io.IOException;

public class Agent {
	public static void main(String[] args) throws IOException {
		Training_Table tt = new Training_Table();
		//get data from the file.
		tt.getCsvData("trip.csv");
		//tt.getCsvData("trip-new.csv");
		Learning learn = new Learning();
		//train the network by input and output.
		learn.learn(tt.input, tt.output);
		Guess guess = new Guess();
		//test by a input array
		double[] preference = {0,0,0,0,0,1,1,1};
		//double[] preference = {0,0,0,0,0,1,1,1,0};
		String destination = guess.selectDestination(guess.guess(preference));
		System.out.println();
		System.out.println("Destination: " + destination);
	}
}
