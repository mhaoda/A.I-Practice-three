import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.util.ArrayList;

public class Test {
public static void main(String[] args) throws IOException {
//	Agent a = new Agent();
//	a.getCsv.getCsvData("trip.csv", 9);
//	double[][] INPUT = a.getCsv.getInput();
//	double[][] OUTPUT = a.getCsv.getOutput();
//	a.getTt().creatTable(INPUT, OUTPUT);

//	double[] preference = {1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0};
//	int maxSign = a.getCs().citySelecter(preference);
//	a.getCs().selectCity(maxSign);
	
//	double[] newInput = {1.0,1.0,1.0,1.0,1.0,1.0,1.0,1.0};
	//double[][] newOutput = {{0,0,0,0,0,1}};
	
//	a.addNewCity(newInput, "China");
//	double[][] INPUT = a.getCsv.addNewCity_Input(newInput, a.getCsv.getInput());
//	double[][] OUTPUT = a.getCsv.addNewCity_Output(newOutput, a.getCsv.getOutput());
//	a.getTt().creatTable(INPUT, OUTPUT);
//	a.getCs().addNewCity("China");
	
//	maxSign = a.getCs().citySelecter(preference);
//	a.getCs().selectCity(maxSign);
	
//	double[][] INPUT = a.getCsv.addNewCity_Input(newInput, a.getCsv.getInput());
//	for(int i=0;i<INPUT.length;i++) {
//	System.out.print(i);
//	for(int j=0;j<INPUT[i].length;j++) {
//		System.out.print(" " +INPUT[i][j] + " ");
//		}
//	System.out.println();
//	}
//	
//	double[][] OUTPUT = a.getCsv.addNewCity_Output(a.getCsv.getOutput());
//	for(int i=0;i<OUTPUT.length;i++) {
//		System.out.print(i);
//		for(int j=0;j<OUTPUT[i].length;j++) {
//			System.out.print(" " +OUTPUT[i][j] + " ");
//		}
//		System.out.println();
//		}
	
//	BufferedReader bf = new BufferedReader(new FileReader("output.txt"));
//	PrintWriter pw = new PrintWriter(new FileWriter("output.txt", true));
//	pw.print(",Japan");
//	pw.flush();
//	System.out.println(bf.readLine());
	
//	citySelecter cs = new citySelecter();
//	System.out.println(cs.cityArray.size());
//	for(int i=0;i<cs.cityArray.size();i++) {
//		System.out.println(cs.cityArray.get(i));
//	}
//	Agent a = new Agent();
//	a.InitialAgent();
//	 GetCsvData g = new GetCsvData();
//	 g.getNewOutput("new_output.txt");
	
	}
}
