import java.io.File;

import org.encog.engine.network.activation.ActivationSigmoid;
import org.encog.ml.data.MLDataSet;
import org.encog.ml.data.basic.BasicMLDataSet;
import org.encog.neural.networks.BasicNetwork;
import org.encog.neural.networks.layers.BasicLayer;
import org.encog.neural.networks.training.propagation.back.Backpropagation;
import org.encog.persist.EncogDirectoryPersistence;

public class Learning {
	int input_units, output_units;
	
	public void creatTable(double[][] INPUT, double[][] OUTPUT) {
		input_units = INPUT[0].length; //input units
		int hidden_units = 4;//hidden units
		output_units = OUTPUT[0].length;//output units
		BasicNetwork network = new BasicNetwork();
		//Create the Input Layer
		network.addLayer(new BasicLayer(null,false,input_units));
		//Hidden Layer
		network.addLayer(new BasicLayer(new ActivationSigmoid(),true,hidden_units));
		//Output Layer
		network.addLayer(new BasicLayer(new ActivationSigmoid(),false,output_units));
		//other options? new ActivationSoftmax()
		network.getStructure().finalizeStructure();
		network.reset();
		MLDataSet trainingSet = new BasicMLDataSet(INPUT, OUTPUT);
		//System.out.println("Encog "+EncogUtility.calculateClassificationError(network, trainingSet)); //returns double
		Backpropagation train=new Backpropagation (network, trainingSet,0.4,0.3);
		
		int epoch = 1;
		do {
		train.iteration();
		epoch++;
		//re-start, if the waiting time is too long.
		if(epoch>5000) {
				System.out.println("Re-start");
				creatTable(INPUT, OUTPUT);
				return;
			}
		} while(train.getError() > 0.01);
		
		train.finishTraining();
		System.out.println("Saving network");
		EncogDirectoryPersistence.saveObject(new File("network_three.eg"), network);
	}
}
