/*
 * the agent for part three
 */
import java.io.IOException;


public class Agent {
	String destination;
	Training_Table getCsv = new Training_Table();
	Learning tt = new Learning();
	Guess cs = new Guess();
	
	
	public Training_Table getGetCsv() {
		return getCsv;
	}

	public Learning getTt() {
		return tt;
	}

	public Guess getCs() {
		return cs;
	}

	public String getDestination() {
		return destination;
	}
	
	
	/*
	 * constructor
	 */
	public Agent() {
		super();
		// TODO Auto-generated constructor stub
		try {
			InitialAgent();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	//getting input and output from the external files
	public void InitialAgent() throws IOException {
		double INPUT[][] = getCsv.getNewInput("new_input.txt");
		double OUTPUT[][] = getCsv.getNewOutput("new_output.txt");
		tt.creatTable(INPUT, OUTPUT);
	}
	/*
	 * get the guessed destination
	 * @param the preference array obtained from the user
	 */
	public void guess(double[] preference) throws IOException {
		int maxSign = cs.citySelecter(preference);
		cs.selectCity(maxSign);
		destination = cs.getDestination();
	}
	
	/*
	 * adding a new destination
	 * @param the input namely the preference of the user.
	 * @param the destinaation
	 */
	public boolean addNewCity(double[] newInput, String city) {
		boolean success = getCs().addNewCity(city);
		if(success) {
			double[][] INPUT = getCsv.addNewCity_Input(newInput, getCsv.getInput());
			double[][] OUTPUT = getCsv.addNewCity_Output(getCsv.getOutput());
			getCsv.setInput(INPUT);
			System.out.println(getCsv.getInput().length);
			getCsv.setOutput(OUTPUT);
			System.out.println("update_output " + getCsv.getOutput().length);
			getTt().creatTable(INPUT, OUTPUT);
		}
		return success;
	}
}
